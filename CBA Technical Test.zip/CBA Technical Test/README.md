# CBA Technical Test Project

## Content

- [CBA Technical Test Project](#cba-technical-test-project)
    - [Content](#content)
    - [Prerequisites](#prerequisites)
    - [How to build project](#how-to-build-project)
    - [How to Run the App](#how-to-run-the-app)
    - [How to run tests](#how-to-run-tests)
    - [API run screen shots](#api-run-screen-shots)
    - [Swagger Documentation](#swagger-documentation)
    - [Recommendations](#recommendations)

## Prerequisites

- The Product API project is built and run using following software versions
    - Java 11 installed
    - Maven 3.6.1
    - (Optional) Eclipse version : 2019-09 R (4.13.0)

## How to build project

- Build with maven command line. This also generates a executable jar file.
    - `mvn clean package`

## How to Run the App

- Program can be executed in following ways:
    - From command line
        - `mvn spring-boot:run`
    - From IDE(eclipse/intelliJ)
        - `By running main class(com.cba.test.CbaTechnicalTestApplication) as Spring Boot Application`
    - By executable jar
        - `java -jar <Project Folder>/target/test-0.0.1-SNAPSHOT.jar`

## How to run tests

- Tests can be run from the command line
    - `mvn test`

## API run screen shots

- Product API test run.
    - ![alt](./img/GetAllProducts.jpg)
- Product API by ID test run.
    - ![alt](./img/GetProductById.jpg)
- HealthCheck API test run.
    - ![alt](./img/GetHealthCheck.jpg)
- Product API backend failure
    - ![alt](./img/NotFoundProduct.jpg)
- Product ID not found test run.
    - ![alt](./img/ProductIdNotFound.jpg)
- Wrong endpoint test run.
    - ![alt](./img/NotFoundEndPoint.jpg)
- Unit/Integration Test result.
    - ![alt](./img/UnitTestCaseResult.jpg)
- Sample log output
    - ![alt](./img/CondoleLogOutput.jpg)

## Swagger Documentation

- Swagger document allows checking, verify and test your API endpoints.
    - Link to access swagger document
        - `<server address>:<port>/v1/swagger-ui.html` eg: `http://localhost:8080/v1/swagger-ui.html`
            - ![alt](./img/SwaggerUI.jpg)

## Recommendations

- If given more time to convert this POC(Proof of concept) to MVP(Minimum viable product) following feature can be added.
    - API Security Protection: to ensure that client requests access data securely.
    - Data Source Connection: For getting actual data from database.
    - Filtering, Sorting, and Pagination: To get the data by filters, page and limit
    - Logs: To records either events that occur in the API, activities of logged users with timestamp.
    - Version Control: To tracking and managing changes to software code by using GIT/TFS.
    - Using SonarQube: to set up and ensure our team is writing high quality code.
    - Using Jenkins: to reliably build, test, and deploy our application.
    - Hosting on cloud: To access our application through the internet
