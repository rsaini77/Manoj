package com.cba.test.controller;

import com.cba.test.modal.Product;
import com.cba.test.service.ProductService;
import io.swagger.annotations.Api;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutionException;

import static com.cba.test.constant.AppConstants.KEY_PRODUCTS;
import static com.cba.test.constant.AppConstants.URI_PRODUCT_GET_ALL;

@Api(value = "Product API Controller", produces = MediaType.APPLICATION_JSON_VALUE, tags = "Product API Controller")
@RestController
public class ProductController {

    ProductService productService;

    @Autowired
    public ProductController(ProductService productService) {
        this.productService = productService;
    }

    @GetMapping(value = URI_PRODUCT_GET_ALL, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Map<String, Object>> getProducts() throws ExecutionException, InterruptedException {
        Map<String, Object> result = new HashMap<>();
        result.put(KEY_PRODUCTS, productService.getProducts().get());
        return ResponseEntity.status(HttpStatus.OK).body(result);
    }

    @GetMapping(value = URI_PRODUCT_GET_ALL + "/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Product> getProductById(@PathVariable(value = "id") Integer id) {
        Product product = productService.getProduct(id);
        if (product == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
        return ResponseEntity.status(HttpStatus.OK).body(product);
    }

}
