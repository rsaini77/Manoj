package com.cba.test.controller;

import io.swagger.annotations.Api;
import org.springframework.boot.web.servlet.error.ErrorController;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import springfox.documentation.annotations.ApiIgnore;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.Map;

import static com.cba.test.constant.AppConstants.KEY_MSG;
import static com.cba.test.constant.AppConstants.KEY_STATUS;
import static com.cba.test.constant.AppConstants.MSG_INTERNAL_SERVER_ERROR;
import static com.cba.test.constant.AppConstants.MSG_NOT_FOUND;
import static com.cba.test.constant.AppConstants.URI_ERROR;

@Api(value = "Error API Controller", produces = MediaType.APPLICATION_JSON_VALUE, tags = "Error API Controller")
@ApiIgnore
@RestController
public class AppErrorController implements ErrorController {

    @GetMapping(URI_ERROR)
    public ResponseEntity<Object> handleError(HttpServletRequest request) {
        Map<String, Object> map = new HashMap<>();
        map.put(KEY_STATUS, 404);
        map.put(KEY_MSG, MSG_NOT_FOUND);
        Object status = request.getAttribute(RequestDispatcher.ERROR_STATUS_CODE);
        if (status != null) {
            int statusCode = Integer.parseInt(status.toString());
            map.put(KEY_STATUS, statusCode);
            if (statusCode == HttpStatus.NOT_FOUND.value()) {
                map.put(KEY_MSG, MSG_NOT_FOUND);
            } else if (statusCode == HttpStatus.INTERNAL_SERVER_ERROR.value()) {
                map.put(KEY_MSG, MSG_INTERNAL_SERVER_ERROR);
            }
        }
        return ResponseEntity.status((Integer) map.get(KEY_STATUS)).body(map);
    }

}
