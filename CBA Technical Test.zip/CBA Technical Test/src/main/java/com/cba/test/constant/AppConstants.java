package com.cba.test.constant;

public class AppConstants {

    public static final String BASE_PACKAGE = "com.cba.test";

    public static final String API_INFO_TITLE = "CBA Technical Test";
    public static final String API_INFO_VERSION = "0.0.1";

    public static final String URI_BASE = "/v1";
    public static final String URI_ERROR = "/error";
    public static final String URI_PRODUCT_GET_ALL = URI_BASE + "/products";
    public static final String URI_HEALTH_CHECK = URI_BASE + "/hc";

    public static final String MSG_NOT_FOUND = "Not found";
    public static final String MSG_INTERNAL_SERVER_ERROR = "An unknown error occurred.";

    public static final String KEY_STATUS = "status";
    public static final String KEY_MSG = "message";
    public static final String KEY_PRODUCTS = "products";
}
