package com.cba.test.service.impl;

import com.cba.test.modal.Product;
import com.cba.test.service.ProductService;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

@Service
public class ProductServiceImpl implements ProductService {

    private final ExecutorService executorService = Executors.newSingleThreadExecutor();

    private final Product[] products = {
            new Product(1, "Apple", "iPhone X", 2000),
            new Product(2, "Samsung", "Note 9", 1400),
            new Product(3, "Google", "Pixel 3", 1309),
            new Product(4, "OnePlus", "6T", 788),
    };

    @Override
    public Future<List<Product>> getProducts() {
        return executorService.submit(() -> {
            boolean shouldThrowError = Math.random() <= 0.2;
            if (shouldThrowError) {
                throw new RuntimeException("An unknown error occurred");
            }
            Thread.sleep((int) (Math.random() * 2000));
            return List.of(products);
        });
    }

    @Override
    public Product getProduct(int id) {
        return Arrays.stream(products).filter(product -> product.getId() == id).findFirst().orElse(null);
    }


}
