package com.cba.test.controller;

import io.swagger.annotations.Api;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

import static com.cba.test.constant.AppConstants.URI_HEALTH_CHECK;

@Api(value = "Health Check API Controller", produces = MediaType.APPLICATION_JSON_VALUE, tags = "Health Check API Controller")
@RestController
public class HealthCheckController {

    @Value("${app.version:unknown}")
    public String version;

    @GetMapping(URI_HEALTH_CHECK)
    public ResponseEntity<Object> healthCheck() {
        Map<String, Object> health = new HashMap<>();
        health.put("version", version);
        return ResponseEntity.status(HttpStatus.OK).body(health);
    }

}
