package com.cba.test.service;

import com.cba.test.modal.Product;

import java.util.List;
import java.util.concurrent.Future;

public interface ProductService {

    Future<List<Product>> getProducts();

    Product getProduct(int id);

}
