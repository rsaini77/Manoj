package com.cba.test;

import com.cba.test.modal.Product;
import com.cba.test.service.impl.ProductServiceImpl;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import java.util.List;
import java.util.concurrent.CompletableFuture;

import static com.cba.test.constant.AppConstants.MSG_INTERNAL_SERVER_ERROR;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.when;

@SpringBootTest
@AutoConfigureMockMvc
public class ProductServiceTest {

    @MockBean
    private ProductServiceImpl productService;

    private final int TEST_PRODUCT_INVALID_ID = 8;
    private final Product TEST_PRODUCT = new Product(1, "Apple", "iPhone X", 2000);

    @Test
    public void testGetProductByValidId() {
        int TEST_PRODUCT_ID = 1;
        when(productService.getProduct(anyInt())).thenReturn(TEST_PRODUCT);
        Product product = productService.getProduct(TEST_PRODUCT_INVALID_ID);
        assertNotNull(product);
        assertEquals(product.getId(), TEST_PRODUCT_ID);
    }

    @Test
    public void testGetProductByInValidId() {
        when(productService.getProduct(anyInt())).thenReturn(null);
        assertNull(productService.getProduct(TEST_PRODUCT_INVALID_ID));
    }

    @Test
    public void testGetAllProducts() throws Exception {
        when(productService.getProducts()).thenReturn(CompletableFuture.completedFuture(List.of(TEST_PRODUCT)));
        assertNotNull(productService.getProducts());
        assertNotNull(productService.getProducts().get());
        assertNotEquals(productService.getProducts().get().size(), 0);
    }

    @Test
    public void testGetAllProductsWithError() {
        when(productService.getProducts()).thenThrow(new RuntimeException(MSG_INTERNAL_SERVER_ERROR));
        assertThrows(RuntimeException.class, () -> productService.getProducts());
    }

}
